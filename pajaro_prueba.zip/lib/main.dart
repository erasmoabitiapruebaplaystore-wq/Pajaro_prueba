
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const PajaroPruebaApp());
}

class PajaroPruebaApp extends StatelessWidget {
  const PajaroPruebaApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pájaro y Elefante',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final AudioPlayer _player = AudioPlayer();
  double _scaleBird = 1.0;
  double _scaleElephant = 1.0;

  Future<void> _playAndJump(String assetPath, bool isBird) async {
    try {
      await _player.stop();
      await _player.play(AssetSource(assetPath.replaceFirst('assets/', '')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error al reproducir sonido: \$e')));
    }
    if (isBird) {
      setState(() => _scaleBird = 1.25);
      await Future.delayed(const Duration(milliseconds: 300));
      setState(() => _scaleBird = 1.0);
    } else {
      setState(() => _scaleElephant = 1.18);
      await Future.delayed(const Duration(milliseconds: 400));
      setState(() => _scaleElephant = 1.0);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double imgWidth = MediaQuery.of(context).size.width * 0.42;
    return Scaffold(
      appBar: AppBar(title: const Text('Pájaro y Elefante')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedScale(
                    scale: _scaleBird,
                    duration: const Duration(milliseconds: 200),
                    child: Image.asset('assets/images/pajaro.png', width: imgWidth),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => _playAndJump('assets/sounds/pajaro.wav', true),
                    child: const Text('Cantar pájaro'),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedScale(
                    scale: _scaleElephant,
                    duration: const Duration(milliseconds: 200),
                    child: Image.asset('assets/images/elefante.png', width: imgWidth),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => _playAndJump('assets/sounds/elefante.wav', false),
                    child: const Text('Rugir elefante'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
